
"""
Emotional processing components
"""
