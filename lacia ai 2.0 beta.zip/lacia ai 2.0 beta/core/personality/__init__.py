"""
Personality system components
"""
