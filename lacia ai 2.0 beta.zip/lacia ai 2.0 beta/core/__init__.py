"""
Core AI system components
"""
